"use client";

import { TerminalContent } from "@/components/terminal-content";

export default function TerminalPageRoute() {
  return <TerminalContent />;
}
