"use client";

import { TerminalContent } from "@/components/terminal-content";

export default function ChatPageRoute() {
  return <TerminalContent />;
}
