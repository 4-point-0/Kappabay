-- AlterTable
ALTER TABLE "Agent" ADD COLUMN "ngrokPort" INTEGER;
