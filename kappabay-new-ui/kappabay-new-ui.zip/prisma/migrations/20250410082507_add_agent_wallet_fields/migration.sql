-- AlterTable
ALTER TABLE "Agent" ADD COLUMN "agentWalletAddress" TEXT;
ALTER TABLE "Agent" ADD COLUMN "agentWalletKey" TEXT;
