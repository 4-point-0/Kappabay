-- AlterTable
ALTER TABLE "Agent" ADD COLUMN "terminalPort" INTEGER;
