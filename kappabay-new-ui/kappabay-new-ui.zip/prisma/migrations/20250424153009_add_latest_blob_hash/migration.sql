-- AlterTable
ALTER TABLE "Agent" ADD COLUMN "latestBlobHash" TEXT;
