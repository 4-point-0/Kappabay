-- AlterTable
ALTER TABLE "Agent" ADD COLUMN "agentType" TEXT;
